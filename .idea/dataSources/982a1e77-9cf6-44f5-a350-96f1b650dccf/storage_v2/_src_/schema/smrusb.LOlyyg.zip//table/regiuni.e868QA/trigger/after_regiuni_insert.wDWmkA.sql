create definer = smrusb_dev@`%` trigger after_regiuni_insert
    after insert
    on regiuni
    for each row
BEGIN
    INSERT INTO istoric_regiuni(regiune, detalii, tip) VALUES(new.id, CONCAT('Regiunea ', new.denumire, ' a fost activata!'), 1);
END;

