create definer = smrusb_dev@`%` trigger after_regiuni_update
    after update
    on regiuni
    for each row
BEGIN
    IF new.stare = 0 THEN
        INSERT INTO istoric_regiuni(regiune, detalii, tip) VALUES(new.id, CONCAT('Regiunea ', new.denumire, ' a fost suspendata!'), new.stare);
    END IF;
    IF new.stare = 1 THEN
        INSERT INTO istoric_regiuni(regiune, detalii, tip) VALUES(new.id, CONCAT('Regiunea ', new.denumire, ' a fost activata!'), new.stare);
    END IF;
END;

